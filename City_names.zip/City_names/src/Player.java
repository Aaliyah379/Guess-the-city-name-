import java.util.Scanner;

public class Player {
    private int numberofPlayer;
    private String name ;


    public Player ( String name, int  score) {
        this.name = name;
        this.numberofPlayer = score;
    }
    Player(int x){

        numberofPlayer= x;
    }


    public int getNumberofPlayer(){
        return numberofPlayer;

    }
    public String getName(){
        return name ;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumberofPlayer(int x) {
        this.numberofPlayer = numberofPlayer;
    }
    @Override
    public String toString() {
        return " " + name;
    }
    public int play(){
        Scanner sn = new Scanner(System.in);
        return sn.nextInt();
    }

}
