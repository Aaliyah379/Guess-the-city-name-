import java.util.Random;

public abstract class Game {
    abstract int Random();
    abstract void Play(int x,int y);
    abstract void Run(int x);
}






