import java.util.Random;
import java.util.Scanner;

public class Loader {

    public static void main(String[] args) {

        Random r = new Random();
  //to display the program
        Scanner input = new Scanner(System.in);
  // String array to keep the cities names
        String[] cities = {"Tallinn", "Baku", "Riga", "Paris", "Berlin"};
        Boolean[] was = new Boolean[5];
        //variable declaration  for the score , correct answ and incorrect answ
        int score = 0;
        int good = 0;
        int bad = 0;
  //loop that sayshow many times we require to run
        for (int d = 0; d < 3; d++) {
            // variable for creating the random name
            int randomint = r.nextInt(5);
            while (was[randomint] == Boolean.FALSE) {
                randomint = r.nextInt(5);
            }
            was[randomint] = false;

            while (was[randomint] == true);
            for (int x = 0; x < 3; x++) {
                //---------------------------------- points how many char contains the name
                System.out.println("The name is " + cities[randomint].length() + " charecters long");
                //prints            -------------------------------------------the first letter of the name
                System.out.println(" Name of the city starts  from letter  " + cities[randomint].charAt(0));
                //prompts user input --Strting from here Nikita's code 
                String answer = input.nextLine();
                //this part makes sure  that even if the user enters lower case letter
                if (answer.equalsIgnoreCase(cities[randomint])) {
                    // part that counts score and counts correct answ.
                    if (x==0){
                        score = score+3;
                        good++;
                    }
                    else if(x==1){
                        score = score+2;
                        good++;
                    }
                    else if (x==2){
                        score = score+1;
                        good++;
                    }
                    System.out.print("Answer is correct. Your score is" + "" +score + ". \n");
                    //prints the info  about correct answ and score
                    break;
                } else {
                    if (x != 2){
                        System.out.print("Answer is not correct. You have " +(2-x) +" chances. ");}
                     //print info  about incorrect answers  and tries
                    if (x == 2){
                        System.out.print("Not correct . Correct answer is " +cities[randomint] +"\n");
                    }      //total info that counts   , incorrect and  provides the  correct name
                    bad++;
                }
            }
        }
        System.out.print("End of game. Correct  answers:" +good +". Incorrect answers: " +bad +". Score: " + ""+ score);
                //prints total info  correc and  incorrect and  score

    }
}









